package com.example.util;

import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;

public class EmailUtility {

    public static void sendEmail(String recipientEmail, String subject, String messageBody) throws MessagingException {
        // Sender's email credentials
        final String senderEmail = "youremail@example.com"; // Replace with your email
        final String senderPassword = "yourpassword"; // Replace with your password

        // Set up mail server properties
        Properties properties = new Properties();
        properties.put("mail.smtp.host", "smtp.gmail.com"); // SMTP server
        properties.put("mail.smtp.port", "587"); // Port
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true"); // Use TLS

        // Authenticate
        Session session = Session.getInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(senderEmail, senderPassword);
            }
        });

        // Compose the email
        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress(senderEmail));
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientEmail));
        message.setSubject(subject);
        message.setText(messageBody);

        // Send the email
        Transport.send(message);
        System.out.println("Email sent successfully to " + recipientEmail);
    }
}
