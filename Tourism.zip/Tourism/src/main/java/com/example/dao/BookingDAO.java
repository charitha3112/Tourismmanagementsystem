package com.example.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.example.model.Booking;
import com.example.util.DatabaseUtil;

public class BookingDAO {
    
    // Method to save booking to the database
    public boolean saveBooking(Booking booking) {
        boolean success = false;
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            // Establish connection to the database (Using a utility method here)
            conn = DatabaseUtil.getConnection();  // Assume DatabaseUtil handles DB connection

            String query = "INSERT INTO bookings (name, email, package_name, start_date, end_date, total_price) VALUES (?, ?, ?, ?, ?, ?)";
            stmt = conn.prepareStatement(query);

            // Set parameters for the prepared statement
            stmt.setString(1, booking.getName());
            stmt.setString(2, booking.getEmail());
            stmt.setString(3, booking.getPackageName());
            stmt.setDate(4, new java.sql.Date(booking.getStartDate().getTime()));
            stmt.setDate(5, new java.sql.Date(booking.getEndDate().getTime()));
            stmt.setDouble(6, booking.getTotalPrice());

            // Execute the query
            int rowsAffected = stmt.executeUpdate();

            // If one or more rows were affected, booking is successful
            if (rowsAffected > 0) {
                success = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();  // Handle SQL exception properly (e.g., log it)
        } finally {
            // Close database resources to avoid memory leaks
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return success;
    }
}
