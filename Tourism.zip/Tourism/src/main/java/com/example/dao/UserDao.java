package com.example.dao;

import com.example.model.User;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.example.util.HibernateUtil;

public class UserDao {
    @SuppressWarnings("deprecation")
	public void saveUser(User user) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction(); // Start transaction
            session.save(user); // Save the user
            transaction.commit(); // Commit the transaction
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback(); // Rollback in case of an error
            }
            e.printStackTrace(); // Print the error for debugging
        }
    }
}
