package com.example.servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.example.dao.BookingDAO;
import com.example.model.Booking;

@WebServlet("/submitBookingServlet")
public class SubmitBookingServlet extends HttpServlet {

    // Handle POST requests for submitting the booking
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get form data from the request
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String packageName = request.getParameter("package");
        String startDateStr = request.getParameter("startDate");
        String endDateStr = request.getParameter("endDate");

        // Convert startDate and endDate to Date objects
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date startDate = null;
        Date endDate = null;
        try {
            startDate = sdf.parse(startDateStr);
            endDate = sdf.parse(endDateStr);
        } catch (ParseException e) {
            e.printStackTrace(); // Handle exception appropriately in a real app
        }

        // Create a Booking object using form data
        Booking booking = new Booking(name, email, packageName, startDate, endDate);

        // Create an instance of BookingDao to interact with the database
        BookingDAO bookingDao = new BookingDAO();

        // Call the saveBooking method to save the booking to the database
        boolean isSuccess = bookingDao.saveBooking(booking);

        // If the booking was successfully saved, set attributes for confirmation page
        if (isSuccess) {
            request.setAttribute("bookingId", booking.getId());  // Assuming Booking has an ID field
            request.setAttribute("customerName", booking.getName());
            request.setAttribute("destination", booking.getPackageName());
            request.setAttribute("checkInDate", booking.getStartDate());
            request.setAttribute("checkOutDate", booking.getEndDate());
            request.setAttribute("totalPrice", booking.getTotalPrice());

            // Forward to the bookingConfirmation.jsp page
            request.getRequestDispatcher("/bookingConfirmation.jsp").forward(request, response);
        } else {
            // If booking fails, send an error response
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Booking failed. Please try again.");
        }
    }
}
