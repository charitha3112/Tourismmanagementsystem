package com.example.servlet;

import com.example.model.Trip;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class MyTripsServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        
        // Mock data (replace this with your database logic)
        ArrayList<Trip> upcomingTrips = new ArrayList<>();
        upcomingTrips.add(new Trip("B12345", "Paris", new Date(), new Date(), "Confirmed"));
        
        ArrayList<Trip> pastTrips = new ArrayList<>();
        pastTrips.add(new Trip("B54321", "New York", new Date(), new Date(), "Completed"));

        // Store trips in session attributes
        session.setAttribute("upcomingTrips", upcomingTrips);
        session.setAttribute("pastTrips", pastTrips);
        
        // Redirect to myTrips.jsp
        response.sendRedirect("myTrips.jsp");
    }
}
