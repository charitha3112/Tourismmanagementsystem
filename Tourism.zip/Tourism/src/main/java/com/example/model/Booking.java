package com.example.model;

import java.util.Date;

public class Booking {
    private int id;
    private String name;
    private String email;
    private String packageName;
    private Date startDate;
    private Date endDate;
    private double totalPrice;  // Example of how you can calculate or store price

    // Constructor
    public Booking(String name, String email, String packageName, Date startDate, Date endDate) {
        this.name = name;
        this.email = email;
        this.packageName = packageName;
        this.startDate = startDate;
        this.endDate = endDate;
        this.totalPrice = calculateTotalPrice();  // You can calculate total price based on package and dates
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    // Example price calculation (based on the number of days)
    private double calculateTotalPrice() {
        long duration = endDate.getTime() - startDate.getTime();
        long days = duration / (1000 * 60 * 60 * 24);  // Convert milliseconds to days
        return days * 100.0;  // Example: $100 per day
    }
}
